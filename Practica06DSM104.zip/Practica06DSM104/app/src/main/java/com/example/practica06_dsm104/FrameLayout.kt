package com.example.practica06_dsm104

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class FrameLayout : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_frame_layout)
    }
}